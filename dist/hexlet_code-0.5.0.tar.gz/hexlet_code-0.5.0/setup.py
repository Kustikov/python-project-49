# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

extras_require = \
{':python_full_version >= "3.8.1" and python_full_version < "4.0.0"': ['flake8>=6.0.0,<7.0.0']}

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.5.0',
    'description': 'collection of games for terminal',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Kustikov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kustikov/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/0f5767cd23e0925c2df1/maintainability)](https://codeclimate.com/github/Kustikov/python-project-49/maintainability)\n### install + run brain-even:\n[![asciicast](https://asciinema.org/a/osoBHM2qAjglcCDZ6P2lBytWW.svg)](https://asciinema.org/a/osoBHM2qAjglcCDZ6P2lBytWW)\n### run brain-calc:\n[![asciicast](https://asciinema.org/a/EHQ3KCQ2QTzv4fxjoUu9hKqpP.svg)](https://asciinema.org/a/EHQ3KCQ2QTzv4fxjoUu9hKqpP)\n### run brain-gcd:\n[![asciicast](https://asciinema.org/a/GmU06rGzxoPHFErNvAZTsMy6Y.svg)](https://asciinema.org/a/GmU06rGzxoPHFErNvAZTsMy6Y)\n### run brain-progression\n[![asciicast](https://asciinema.org/a/lQYIddCT2hipGx9q3ZJQEctRY.svg)](https://asciinema.org/a/lQYIddCT2hipGx9q3ZJQEctRY)\n### run brain-prime\n[![asciicast](https://asciinema.org/a/z6I7YEXzEuxTmF7BmjSC9MJwL.svg)](https://asciinema.org/a/z6I7YEXzEuxTmF7BmjSC9MJwL)\n',
    'author': 'kustikov',
    'author_email': 'pasha_k1987@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
