# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

extras_require = \
{':python_full_version >= "3.8.1" and python_full_version < "4.0.0"': ['flake8>=6.0.0,<7.0.0']}

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.2',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Kustikov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kustikov/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/0f5767cd23e0925c2df1/maintainability)](https://codeclimate.com/github/Kustikov/python-project-49/maintainability)\n',
    'author': 'kustikov',
    'author_email': 'pasha_k1987@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
